package controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import model.Appointment;



public class AppointmentHelper {
EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("DoggyChicStevens");
	
	public void insertAppointment(Appointment toAdd) {
		// TODO Auto-generated method stub
		EntityManager em = emfactory.createEntityManager();
		em.getTransaction().begin();
		em.persist(toAdd);
		em.getTransaction().commit();
		em.close();
	}
	
	
	public void deleteAppointment(Appointment toDelete) {
		// TODO Auto-generated method stub
		
		EntityManager em = emfactory.createEntityManager();
		em.getTransaction().begin();
		Appointment find = em.find(Appointment.class, toDelete.getAppointment_id());
		em.remove(find);
		em.getTransaction().commit();
		em.close();
	}
	
	public Appointment searchForAppointmentById(int idToEdit) {
		// TODO Auto-generated method stub
		EntityManager em = emfactory.createEntityManager();
		em.getTransaction().begin();
		Appointment foundAppointment = em.find(Appointment.class, idToEdit);
		em.close();
		return foundAppointment;
	}

	public List<Appointment> showAllAppointments() {
		// TODO Auto-generated method stub
		EntityManager em = emfactory.createEntityManager();
		TypedQuery<Appointment> allResults = em.createQuery("select app from Appointment app", Appointment.class);
		List<Appointment> allAppointments = allResults.getResultList();
		em.close();
		return allAppointments;
		
	}
	public void updateAppointment(Appointment toEdit) {
		// TODO Auto-generated method stub
		EntityManager em = emfactory.createEntityManager();
		em.getTransaction().begin();
		em.merge(toEdit);
		em.getTransaction().commit();
		em.close();
		
	}
}
